=============================================

Hello, Thanks for downloading our font

=============================================

By installing or using this font, you are agree to the Product Usage Agreement:

- This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
- Here is the link to purchase full version and commercial license: https://payhip.com/b/Jki6Z
- Any donation are very appreciated. Paypal account for donation : https://paypal.me/aswangga

=============================================

[Personal use] refers to all usage that does not generate financial income in a business manner, for instance:

- personal scrapbooking for yourself
- recreational websites and blogs for friends and family
- prints such as flyers, posters, t-shirts for churches, charities, and non-profit organizations.

[Commercial use] refers to usage in a business environment, including:

- business cards, logos, advertising, websites for companies
- t-shirts, books, apparel that will be sold for money
- flyers, posters for events that charge admission
- freelance graphic design work
- anything that will generate direct or indirect income.

[Modification]
All fonts may not be altered, adapted or built upon.

[Distribution]
All fonts may not be sold or published.

=============================================

Copyright 2021 Salamahstudio.